package vorobiev.example.com;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button btnImage, btnDecr, btnAbout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();
    }
    public void addListenerOnButton(){
        btnImage =(Button)findViewById(R.id.buttonNewYearImage);
        btnDecr =(Button)findViewById(R.id.buttonAboutNewYear);
        btnAbout = (Button)findViewById(R.id.buttonAboutPage);

        btnImage.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent("vorobiev.example.com.ActivityImages");
                        startActivity(intent);


                    }
                }
        );

        btnDecr.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent("vorobiev.example.com.DecriprionActivity");
                        startActivity(intent);


                    }
                }
        );

        btnAbout.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Toast toast = Toast.makeText(MainActivity.this
                        ,"GO zxc&&&", Toast.LENGTH_LONG);

                        toast.setGravity(Gravity.CENTER,0,0);
                        LinearLayout toastContainer = (LinearLayout) toast.getView();

                        ImageView zxc = new ImageView(getApplicationContext());
                        zxc.setImageResource(R.drawable.zxc);

                        toastContainer.addView(zxc, 0);

                        toast.show();


                    }
                }
        );






    }

}
