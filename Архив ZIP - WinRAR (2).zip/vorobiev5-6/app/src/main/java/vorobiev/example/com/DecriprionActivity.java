package vorobiev.example.com;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DecriprionActivity extends AppCompatActivity {
    private Button btnDecrBack;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decriprion);
        Back_decr();


    }
    public void Back_decr(){
        btnDecrBack = (Button)findViewById(R.id.buttonDecrBack);
        btnDecrBack.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent Back_decr_act = new Intent(".MainActivity");
                        startActivity(Back_decr_act);

                    }
                }


        );

    }
}
